SlimefunLegacyRP.zip
Primary base: Slimefun-Resourcepack(1).zip
Merged: Pylon/Rebar/RebarMobs, Magic, MMOItems, IAWeapons (Slimefun Warfare support), MC Icons, Ores.
Generated ItemsAdder pack is used only as a donor for IAWeapons/MMOItems/MCIcons generated models, item mappings, and modern atlas data.
Compatibility target: Minecraft Java 1.21.11+ (including 26.1, 26.2, 26.3).
Slimefun mappings have priority; Pylon string CustomModelData is wrapped around numeric mappings; player-head special fallback is preserved.
